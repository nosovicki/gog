/*
 * Design of KCachegrind.
 * This is for doxygen generated documentation
 *
 * (C) 2003, Josef Weidendorfer
 */

/**
   Terms
   ======

   Code Position

     This can be
     - a machine instruction,
     - a source line,
     - a basic block,
     - a function,
     - a method of a C++ class,
     - a function/method defined in a source file,
     - a function/method linked into an ELF object.
     or a call among two of the above mentioned positions.
     Relation:
     - A machine instruction relates 1 source line and 1 basic block
     - A source line can relate to multiple functions (when inlined)
     - A functions relates to 1 C++ class, 1 source file, 1 ELF object.
     Each action has a location:
     - Machine adress range (start/length)
     - Range of lines from source files.
     - ELF object containing compiled function.


   Event

     Events happen while an instruction at a given code position is executed.
     Thus, events are related to positions.
     Examples for events are
     - machine instruction executed,
     - data read/write access happend,
     - L1/L2/TLB cache miss happened,
     - processor cycle finished,
     - (high resolution) timer incremented.


   Profile metrics for code positions

     For events happening at a position inside a time range of running the program,
     the number of events that happend can be given.
     These numbers give you a profile of a time range of the program run.


  Data model of KCachegrind
  =========================

  KCachegrind stores a number of profile event metrics for each action.
  General abstract classes for metric storage are
    TraceCost           : fixed number of event metrics
    TraceCallCost       : including call count
    TraceInclusiveCost  : including a second TraceCost for cost cumulation
  and classes for lists of metrics with autmatic summation:
    TraceListCost
    TraceCallListCost
    TraceInclusiveListCost
    
  As the type of events meassured by a profiling tool can be different,
  there is no fixed mapping of a stored metric to a specific event type.
  Thus, a TraceCost simple can hold a maximum number of event metrics.


  Misc notes on classes
  =====================

  All cost items are classes prefixed with "Trace".
  "TraceCost" holds basic cost metrics for the simplest, smallest
  trace entity: These are events counted for an instruction at
  a specific memory address of the traced program.
  All other cost items are derived from TraceCost, and add needed
  cost metrics, e.g. for a call the number of calls that happened.
 
  Abstract, i.e. never instantiated cost items are
  - TraceCost: Basic cost metrics (instr/read/write access + cache events)
  - TraceCallCost: Additional call count cost metric.
  - TraceCumulativeCost: Additional TraceCost aggregated.
  - TraceListCost: Adds dependency to a list of TraceCost's
  - TraceCallListCost: same for list of TraceCallCost's
  - TraceCumulativeListCost: same for list of TraceCumulativeCost's
  - TraceCostItem: Base for cost items for "interesting" costs:
               TraceFunction, TraceClass, TraceFile, TraceObject
 
  The smallest Cachegrind output is trace data indexed by a source
  line number, a TracePartLine. Another one is a call from one
  source line of a function to another function, a TracePartLineCall.
  All other cost items derive the value by summation of cost metrics
  from TraceLineItem and TracePartLineCall costs; their cost is
  calculated lazy on demand and cached afterwards.
 
  For cost items, which are sums over all trace files read in, the
  summed cost metrics change when e.g. a new trace file is read.
  Thus, their cached costs are invalidated, and again recalculated
  only on demand. In the following list, theses cost items are called
  "dynamic", the other "fixed" (but neverless calculated lazy).
 
   Cost Item          Type      Summation of ...
 
   TracePartLineCall  fixed     Read from trace file
   TracePartLine      fixed     Read from trace file
   TracePartCall      fixed     TracePartLineCall's
   TraceLineCall      dynamic   TracePartLineCall's
   TraceCall          dynamic   TraceLineCall's
   TraceLine          dynamic   TracePartLine's and TraceLineCall's
   TracePartFunction  fixed     TracePartLine's / TracePartCall's
   TraceFunction      dynamic   TraceLine's / TraceCall's (called from)
   TracePartClass     fixed     TracePartFunction's
   TraceClass         dynamic   TraceFunction's
   TracePartFile      fixed     TracePartFunction's
   TraceFile          dynamic   TraceFunction's
   TracePartObject    fixed     TracePartFunction's
   TraceObject        dynamic   TraceFunction's
   TracePart          fixed     TracePartLine's
   TraceData          dynamic   TracePart's
 
  As there exists only one TraceData object for a traced program, its the
  owner of some "high level" cost items. The following shows the owner
  relationship of the cost item classes, together with references.
 
   Cost Item          Owner (& back ref)   Other References to
 
   TracePartLineCall  TraceLineCall
   TracePartCall      TraceCall            TracePartLineCall's
   TracePartLine      TraceLine            TracePartLineCall's
   TracePartFunction  TraceFunction
   TracePartClass     TraceClass           TracePart
   TracePartFile      TraceFile            TracePart
   TracePartObject    TraceObject          TracePart
   TraceLineCall      TraceCall            TracePartLineCall's
   TraceCall          TraceFunction        TracePartCall's
   TraceLine          TraceData            TraceLineCall's
   TraceFunction      TraceData            TraceCall's (calling)
   TraceClass         TraceData
   TraceFile          TraceData
   TraceObject        TraceData
   TracePart          TraceData
   TraceData          Main Application
 
  Convention:
  - The owner has a factory method for owned objects,
    and calls addXXX() to install references in other objects
  - The owner is first arg in a constructor.

*/

   
    

  
