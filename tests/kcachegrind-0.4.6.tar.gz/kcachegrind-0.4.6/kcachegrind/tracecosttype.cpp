/*
 * Part of KCacheGrind
 *
 */

#include <qregexp.h>

#include "tracecosttype.h"

#define TRACE_DEBUG      0
#define TRACE_ASSERTIONS 0


//---------------------------------------------------
// TraceCostType

QPtrList<TraceCostType>* TraceCostType::_knownTypes = 0;

TraceCostType::TraceCostType(QString name,  QString longName, QString formula)
{
  _name = name;
  _longName = longName;
  _formula = formula;
  _mapping = 0;
  _realIndex = TraceCost::InvalidIndex;
  _parsed = false;
  _inParsing = false;

  for (int i=0; i<TraceCost::MaxRealIndex;i++)
    _coefficient[i] = 0;
}

void TraceCostType::setFormula(QString formula)
{
  _formula = formula;
  _realIndex = TraceCost::InvalidIndex;
  _parsed = false;
}

void TraceCostType::setMapping(TraceCostMapping* m)
{
  _parsed = false;
  _mapping = m;
}

// setting the index to TraceCost::MaxRealIndex makes it a
// real type with unspecified index
void TraceCostType::setRealIndex(int i)
{
  if (i<0 || i>TraceCost::MaxRealIndex)
    i=TraceCost::InvalidIndex;

  _realIndex = i;
  _formula = QString::null;
}

// checks for existing types and sets coefficients
bool TraceCostType::parseFormula()
{
  if (_parsed) return true;
  if (_inParsing) {
    qDebug("TraceCostType::parseFormula: Recursion detected.");
    return false;
  }
  _inParsing = true;

  if (!_mapping) {
    qDebug("TraceCostType::parseFormula: No mapping set!");
    return false;
  }

  for (int i=0; i<TraceCost::MaxRealIndex;i++)
    _coefficient[i] = 0;

  QRegExp rx( "((?:\\+|\\-)?)\\s*(\\d*)\\s*\\*?\\s*(\\w+)" );

  int factor, pos;
  QString costName;
  TraceCostType* costType;

  pos = 0;
  while (1) {
    pos = rx.search(_formula, pos);
    if (pos<0) break;
    pos += rx.matchedLength();
    if (rx.cap(0).isEmpty()) break;

    //qDebug("parseFormula: matched '%s','%s','%s'",
    //       rx.cap(1).ascii(), rx.cap(2).ascii(), rx.cap(3).ascii());

    costName = rx.cap(3);
    costType = _mapping->type(costName);
    if (!costType) {
      //qDebug("Cost type '%s': In formula cost '%s' unknown.",
      //       _name.ascii(), costName.ascii());
      return false;
    }

    factor = (rx.cap(2).isEmpty()) ? 1 : rx.cap(2).toInt();
    if (rx.cap(1) == "-") factor = -factor;

    if (costType->isReal())
      _coefficient[costType->realIndex()] += factor;
    else {
      costType->parseFormula();
      for (int i=0; i<TraceCost::MaxRealIndex;i++)
        _coefficient[i] += factor * costType->_coefficient[i];
    }
  }

  _inParsing = false;
  _parsed = true;

  return true;
}

QString TraceCostType::parsedFormula()
{
  QString res;

  if (!parseFormula()) return res;

  for (int i=0; i<=TraceCost::MaxRealIndex;i++) {
    int c = _coefficient[i];
    if (c == 0) continue;

    if (!res.isEmpty()) {
      res += " ";
      if (c>0) res += "+ ";
    }
    if (c<0) { res += "- "; c = -c; }
    res += QString::number(c);

    TraceCostType* t = _mapping->type(i);
    if (!t) continue;

    if (!t->name().isEmpty())
      res += QString(" * %1").arg(t->name());
  }

  return res;
}

TraceCost::SubCost TraceCostType::subCost(TraceCost* c)
{
  if (_realIndex != TraceCost::InvalidIndex)
    return c->subCost(_realIndex);

  if (!_parsed) {
    if (!parseFormula()) return 0;
  }
  TraceCost::SubCost res = 0;

  for (int i = 0;i<_mapping->realCount();i++)
    if (_coefficient[i] != 0)
      res += _coefficient[i] * c->subCost(i);

  return res;
}

TraceCostType* TraceCostType::knownRealType(QString n)
{
  if (!_knownTypes) return 0;

  TraceCostType* t;
  for (t=_knownTypes->first();t;t=_knownTypes->next())
    if (t->isReal() && (t->name() == n)) {
      TraceCostType* type = new TraceCostType(*t);
      return type;
    }

  return 0;
}

TraceCostType* TraceCostType::knownVirtualType(QString n)
{
  if (!_knownTypes) return 0;

  TraceCostType* t;
  for (t=_knownTypes->first();t;t=_knownTypes->next())
    if (!t->isReal() && (t->name() == n)) {
      TraceCostType* type = new TraceCostType(*t);
      return type;
    }

  return 0;
}

// we take ownership
void TraceCostType::add(TraceCostType* t)
{
  if (!t) return;

  t->setMapping(0);

  if (!_knownTypes)
    _knownTypes = new QPtrList<TraceCostType>;

  _knownTypes->append(t);
}

int TraceCostType::knownTypeCount()
{
  if (!_knownTypes) return 0;

  return _knownTypes->count();
}

TraceCostType* TraceCostType::knownType(int i)
{
  if (!_knownTypes) return 0;
  if (i<0 || i>=(int)_knownTypes->count()) return 0;

  return _knownTypes->at(i);
}


//---------------------------------------------------
// TraceCostMapping

TraceCostMapping::TraceCostMapping()
{
  _realCount = 0;
  _virtualCount = 0;
  for (int i=0;i<TraceCost::MaxRealIndex;i++) _real[i] = 0;
  for (int i=0;i<TraceCost::MaxRealIndex;i++) _virtual[i] = 0;
}

TraceCostMapping::~TraceCostMapping()
{
  for (int i=0;i<TraceCost::MaxRealIndex;i++)
    if (_real[i]) delete _real[i];

  for (int i=0;i<TraceCost::MaxRealIndex;i++)
    if (_virtual[i]) delete _virtual[i];
}

TraceSubMapping* TraceCostMapping::subMapping(QString types, bool create)
{
  QRegExp rx( "(\\w+)" );

  // first check if there's enough space in the mapping
  int newCount = 0;
  int pos = 0;
  while (1) {
    pos = rx.search(types, pos);
    if (pos<0) break;
    pos += rx.matchedLength();

    if (realIndex(rx.cap(1)) == TraceCost::InvalidIndex)
      newCount++;
  }

  if (!create && (newCount>0)) return 0;

  if (newCount+_realCount > TraceCost::MaxRealIndex) {
    qDebug("TraceCostMapping::subMapping: No space for %d sub costs",
           newCount);
    return 0;
  }

  TraceSubMapping* sm = new TraceSubMapping(this);

  pos = 0;
  while (1) {
    pos = rx.search(types, pos);
    if (pos<0) break;
    pos += rx.matchedLength();

    sm->append(addReal(rx.cap(1)));
  }

  return sm;
}


int TraceCostMapping::addReal(QString t)
{
  int index = realIndex(t);
  if (index>=0) return index;

  TraceCostType* ct = TraceCostType::knownRealType(t);
  if (!ct) ct = new TraceCostType(t, t);

  // make it real
  ct->setRealIndex();

  return add(ct);
}

// add a cost type to a mapping
// this transfers ownership of the type!
int TraceCostMapping::add(TraceCostType* ct)
{
  if (!ct) return TraceCost::InvalidIndex;

  ct->setMapping(this);

  if (ct->isReal()) {
    if (_realCount >= TraceCost::MaxRealIndex) {
      qDebug("WARNING: Maximum for real cost types reached (on adding '%s')",
             ct->name().ascii());
      return TraceCost::InvalidIndex;
    }
    _real[_realCount] = ct;
    ct->setRealIndex(_realCount);

    _realCount++;
    return _realCount-1;
  }

  if (_virtualCount >= TraceCost::MaxRealIndex) {
    qDebug("WARNING: Maximum for virtual cost types reached (on adding '%s')",
           ct->name().ascii());
    return TraceCost::InvalidIndex;
  }
  _virtual[_virtualCount] = ct;
  _virtualCount++;
  return _virtualCount-1;
}


TraceCostType* TraceCostMapping::realType(int t)
{
  if (t<0 || t>=_realCount) return 0;
  return _real[t];
}

TraceCostType* TraceCostMapping::virtualType(int t)
{
  if (t<0 || t>=_virtualCount) return 0;
  return _virtual[t];
}


TraceCostType* TraceCostMapping::type(int t)
{
  if (t<0) return 0;
  if (t<_realCount) return _real[t];

  t -= TraceCost::MaxRealIndex;
  if (t<0) return 0;
  if (t<_virtualCount) return _virtual[t];

  return 0;
}

TraceCostType* TraceCostMapping::type(QString name)
{
  for (int i=0;i<_realCount;i++)
    if (_real[i] && (_real[i]->name() == name))
      return _real[i];

  for (int i=0;i<_virtualCount;i++)
    if (_virtual[i] && (_virtual[i]->name() == name))
      return _virtual[i];

  return 0;
}

TraceCostType* TraceCostMapping::typeForLong(QString name)
{
  for (int i=0;i<_realCount;i++)
    if (_real[i] && (_real[i]->longName() == name))
      return _real[i];

  for (int i=0;i<_virtualCount;i++)
    if (_virtual[i] && (_virtual[i]->longName() == name))
      return _virtual[i];

  return 0;
}


int TraceCostMapping::realIndex(QString name)
{
  for (int i=0;i<_realCount;i++)
    if (_real[i] && (_real[i]->name() == name))
      return i;

  return TraceCost::InvalidIndex;
}

int TraceCostMapping::index(QString name)
{
  for (int i=0;i<_realCount;i++)
    if (_real[i] && (_real[i]->name() == name))
      return i;

  for (int i=0;i<_virtualCount;i++)
    if (_virtual[i] && (_virtual[i]->name() == name))
      return TraceCost::MaxRealIndex + i;

  return TraceCost::InvalidIndex;
}

int TraceCostMapping::addKnownVirtualTypes()
{
  int addCount = 0;
  int addDiff, i;
  int knownCount = TraceCostType::knownTypeCount();

  while (1) {
    addDiff = 0;
    for (i=0; i<knownCount; i++) {
      TraceCostType* t = TraceCostType::knownType(i);
      if (t->isReal()) continue;
      if (index(t->name()) != TraceCost::InvalidIndex) continue;
      t->setMapping(this);
      if (t->parseFormula()) {
        addDiff++;
        add(new TraceCostType(t->name(), t->longName(), t->formula()));
      }
      t->setMapping(0);
    }
    if (addDiff == 0) break;
    addCount += addDiff;
  }
  return addCount;
}


//---------------------------------------------------
// TraceSubMapping

TraceSubMapping::TraceSubMapping(TraceCostMapping* mapping)
{
  _mapping = mapping;
  _count = 0;
}

bool TraceSubMapping::append(QString type, bool create)
{
  if (!_mapping) return false;
  int index = create ? _mapping->addReal(type) : _mapping->realIndex(type);

  return append(index);
}

bool TraceSubMapping::append(int type)
{
  if (!_mapping) return false;
  if ((type<0) || (type >= _mapping->realCount())) return false;

  if ( _count>=  TraceCost::MaxRealIndex) return false;
  _realIndex[_count] = type;
  _count++;

  return true;
}


