#include <klocale.h>
/****************************************************************************
** Form implementation generated from reading ui file './tracesourcedlg.ui'
**
** Created: Mon Aug 11 11:48:56 2003
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.1.1   edited Nov 21 17:40 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "tracesourcedlg.h"

#include <qvariant.h>
#include <kcombobox.h>
#include <kfiledialog.h>
#include <qcheckbox.h>
#include <qframe.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>

#include "./tracesourcedlg.ui.h"
/* 
 *  Constructs a TraceSourceDlg as a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
TraceSourceDlg::TraceSourceDlg( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )

{
    if ( !name )
	setName( "TraceSourceDlg" );
    TraceSourceDlgLayout = new QVBoxLayout( this, 11, 6, "TraceSourceDlgLayout"); 

    Layout3 = new QGridLayout( 0, 1, 1, 0, 6, "Layout3"); 

    TraceExecutable = new KHistoryCombo( this, "TraceExecutable" );
    TraceExecutable->setEnabled( FALSE );
    TraceExecutable->setInsertionPolicy( KHistoryCombo::AtTop );
    TraceExecutable->setAutoCompletion( TRUE );
    TraceExecutable->setDuplicatesEnabled( FALSE );
    TraceExecutable->setContextMenuEnabled( TRUE );

    Layout3->addWidget( TraceExecutable, 1, 1 );

    TraceDirectory = new KHistoryCombo( this, "TraceDirectory" );
    TraceDirectory->setEnabled( TRUE );
    TraceDirectory->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)0, 1, 0, TraceDirectory->sizePolicy().hasHeightForWidth() ) );
    TraceDirectory->setInsertionPolicy( KHistoryCombo::AtTop );
    TraceDirectory->setAutoCompletion( TRUE );
    TraceDirectory->setDuplicatesEnabled( FALSE );
    TraceDirectory->setContextMenuEnabled( TRUE );

    Layout3->addWidget( TraceDirectory, 0, 1 );

    PushButton11 = new QPushButton( this, "PushButton11" );
    PushButton11->setEnabled( FALSE );

    Layout3->addWidget( PushButton11, 1, 2 );

    CheckBox1 = new QCheckBox( this, "CheckBox1" );

    Layout3->addWidget( CheckBox1, 1, 0 );
    QSpacerItem* spacer = new QSpacerItem( 0, 0, QSizePolicy::Minimum, QSizePolicy::Expanding );
    Layout3->addItem( spacer, 2, 1 );

    TextLabel2 = new QLabel( this, "TextLabel2" );
    TextLabel2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)1, (QSizePolicy::SizeType)5, 0, 0, TextLabel2->sizePolicy().hasHeightForWidth() ) );

    Layout3->addWidget( TextLabel2, 0, 0 );

    PushButton11_2 = new QPushButton( this, "PushButton11_2" );

    Layout3->addWidget( PushButton11_2, 0, 2 );
    TraceSourceDlgLayout->addLayout( Layout3 );

    Line3 = new QFrame( this, "Line3" );
    Line3->setFrameShape( QFrame::HLine );
    Line3->setFrameShadow( QFrame::Sunken );
    Line3->setFrameShape( QFrame::HLine );
    TraceSourceDlgLayout->addWidget( Line3 );

    Layout11 = new QHBoxLayout( 0, 0, 6, "Layout11"); 

    PushButton9 = new QPushButton( this, "PushButton9" );
    Layout11->addWidget( PushButton9 );
    QSpacerItem* spacer_2 = new QSpacerItem( 0, 0, QSizePolicy::Expanding, QSizePolicy::Minimum );
    Layout11->addItem( spacer_2 );

    PushButton9_2 = new QPushButton( this, "PushButton9_2" );
    Layout11->addWidget( PushButton9_2 );
    TraceSourceDlgLayout->addLayout( Layout11 );
    languageChange();
    resize( QSize(362, 138).expandedTo(minimumSizeHint()) );

    // signals and slots connections
    connect( PushButton9_2, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( PushButton9, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( CheckBox1, SIGNAL( toggled(bool) ), PushButton11, SLOT( setEnabled(bool) ) );
    connect( CheckBox1, SIGNAL( toggled(bool) ), TraceExecutable, SLOT( setEnabled(bool) ) );
    connect( PushButton11_2, SIGNAL( clicked() ), this, SLOT( browseDirectorySlot() ) );
    connect( PushButton11, SIGNAL( clicked() ), this, SLOT( browseExecSlot() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
TraceSourceDlg::~TraceSourceDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void TraceSourceDlg::languageChange()
{
    setCaption( tr2i18n( "Trace Source..." ) );
    PushButton11->setText( tr2i18n( "..." ) );
    CheckBox1->setText( tr2i18n( "Run:" ) );
    TextLabel2->setText( tr2i18n( "Directory:" ) );
    PushButton11_2->setText( tr2i18n( "..." ) );
    PushButton9->setText( tr2i18n( "Load" ) );
    PushButton9_2->setText( tr2i18n( "Cancel" ) );
}

#include "tracesourcedlg.moc"
