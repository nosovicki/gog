/*
 * Part of KCacheGrind
 *
 */

#include <klocale.h>

#include "tracecost.h"
#include "tracecosttype.h"
#include "tracepart.h"

#define TRACE_DEBUG      0
#define TRACE_ASSERTIONS 0


//---------------------------------------------------
// TraceCost

TraceCost::TraceCost()
{
  _part = 0;
  _dep = 0;
  _dirty = true;

  clear();
}

QString TraceCost::typeName(CostType t)
{
  switch(t) {
  case Abstract:           return I18N_NOOP("Abstract Cost Item");
  case PartLine:           return I18N_NOOP("Part Source Line");
  case Line:               return I18N_NOOP("Source Line");
  case PartLineCall:       return I18N_NOOP("Part Line Call");
  case LineCall:           return I18N_NOOP("Line Call");
  case PartCall:           return I18N_NOOP("Part Call");
  case Call:               return I18N_NOOP("Call");
  case FunctionCall:       return I18N_NOOP("Function Call");
  case ClassCall:          return I18N_NOOP("Class Call");
  case FileCall:           return I18N_NOOP("File Call");
  case ObjectCall:         return I18N_NOOP("ELF Object Call");
  case Cycle:              return I18N_NOOP("Cycle");
  case FunctionCycle:      return I18N_NOOP("FunctionCycle");
  case ClassCycle:         return I18N_NOOP("ClassCycle");
  case FileCycle:          return I18N_NOOP("FileCycle");
  case ObjectCycle:        return I18N_NOOP("ObjectCycle");
  case PartFunction:       return I18N_NOOP("Part Function");
  case FunctionSourceFile: return I18N_NOOP("Function Source File");
  case Function:           return I18N_NOOP("Function");
  case PartClass:          return I18N_NOOP("Part Class");
  case Class:              return I18N_NOOP("Class");
  case PartFile:           return I18N_NOOP("Part Source File");
  case File:               return I18N_NOOP("Source File");
  case PartObject:         return I18N_NOOP("Part ELF Object");
  case Object:             return I18N_NOOP("ELF Object");
  case Part:               return I18N_NOOP("Profile Part");
  case Data:               return I18N_NOOP("Program Trace");
  default:                 return I18N_NOOP("Unknown Cost Item");
  }
}

TraceCost::CostType TraceCost::costType(QString s)
{
  // This is the default cost Type
  if (s.isEmpty()) return Function;

  CostType type;
  for (int i=0; i<MaxCostType;i++) {
    type = (CostType) i;
    if (typeName(type) == s)
      return type;
  }
  return NoCostType;
}


void TraceCost::clear()
{
  for (int i=0; i<MaxRealIndex;i++)
    _cost[i] = 0;

  // a cost change has to be propagated (esp. in subclasses)
  invalidate();
}

void TraceCost::set(TraceSubMapping* sm, const char* s)
{
  int i,  index;
  for (i=0; i<MaxRealIndex;i++) _cost[i] = 0;

  i = 0;
  SubCost v = 0;

  index = sm ? sm->realIndex(i) : TraceCost::InvalidIndex;
  if (s && (index != TraceCost::InvalidIndex)) {
    while(*s) {
      if (*s == ' ') {
        _cost[index] = v;
        v = 0;

        i++;
        index = sm->realIndex(i);
        if (index == TraceCost::InvalidIndex) break;

        while (*s == ' ')
          s++;
        continue;
      }
      else if (*s >= '0' && *s <= '9') {
        v = 10* v + (*s-'0');
        s++;
        continue;
      }
      break;
    }
  }
  if (index != TraceCost::InvalidIndex) _cost[index] = v;

  // a cost change has to be propagated (esp. in subclasses)
  invalidate();
}

void TraceCost::addCost(TraceSubMapping* sm, const char* s)
{
  int i = 0, index;
  SubCost v = 0;

  index = sm ? sm->realIndex(i) : TraceCost::InvalidIndex;
  if (s && (index != TraceCost::InvalidIndex)) {
    while(*s) {
      if (*s == ' ') {
        _cost[index] += v;
        v = 0;

        i++;
        index = sm->realIndex(i);
        if (index == TraceCost::InvalidIndex) break;

        while (*s == ' ')
          s++;
        continue;
      }
      else if (*s >= '0' && *s <= '9') {
        v = 10* v + (*s-'0');
        s++;
        continue;
      }
      break;
    }
  }

  if (index != TraceCost::InvalidIndex) _cost[index] += v;

  // a cost change has to be propagated (esp. in subclasses)
  invalidate();

#if TRACE_DEBUG
  _dirty = false; // don't recurse !
  qDebug("%s\n now %s", fullName().ascii(), TraceCost::costString().ascii());
  _dirty = true; // because of invalidate()
#endif
}


void TraceCost::addCost(TraceCost* item, TraceCostMapping* m)
{
  if (!item) return;

  // we have to update the other item if needed
  // because we access the item costs directly
  if (item->_dirty) item->update();

  int maxIndex = m ? (m->realCount()) : TraceCost::MaxRealIndex;

  for (int i = 0; i<maxIndex; i++)
    _cost[i] += item->_cost[i];

  // a cost change has to be propagated (esp. in subclasses)
  invalidate();

#if TRACE_DEBUG
  _dirty = false; // don't recurse !
  qDebug("%s added cost item\n %s\n  now %s",
         fullName().ascii(), item->fullName().ascii(),
         TraceCost::costString().ascii());
  _dirty = true; // because of invalidate()
#endif
}



void TraceCost::addCost(int type, SubCost value)
{
  if (type>=0 && type<MaxRealIndex) {
    _cost[type] += value;

    // a cost change has to be propagated (esp. in subclasses)
    invalidate();
  }
}

TraceCost TraceCost::diff(TraceCost* item)
{
  TraceCost res;

  // we have to update the other item if needed
  // because we access the item costs directly
  if (item->_dirty) item->update();

  for (int i=0; i<MaxRealIndex;i++)
    res._cost[i] = item->_cost[i] - _cost[i];

  return res;
}

QString TraceCost::costString(TraceCostMapping* m)
{
  QString res;

  if (_dirty) update();

  int maxIndex = m ? m->realCount() : TraceCost::MaxRealIndex;
  for (int i = 0; i<maxIndex; i++) {
    if (!res.isEmpty()) res += ", ";
    if (m) res += m->type(i)->name() + " ";

    res += QString::number((ulong)_cost[i]);
  }
  return res;
}

QString TraceCost::name()
{
  if (_part) {
    return i18n("%1 from %2")
      .arg(_dep->name())
      .arg(_part->name());
  }

  if (_dep)
    return _dep->name();

  return i18n("(unnamed)");
}


QString TraceCost::fullName()
{
  return QString("%1 %2")
    .arg(typeName(type())).arg(prettyName());
}

QString TraceCost::toString()
{
  return fullName();
  // FIXME
  // return QString("%1\n  [%3]").arg(fullName()).arg(costString());
}

void TraceCost::invalidate()
{
  if (_dirty) return;
  _dirty = true;

  if (_dep)
    _dep->invalidate();
}

void TraceCost::update()
{
  _dirty = false;
}

// this only
TraceCost::SubCost TraceCost::subCost(int idx)
{
  if (idx<0 || idx>MaxRealIndex) return 0;

  // update if needed as cost could be calculated dynamically in subclasses
  if (_dirty) update();
  return _cost[idx];
}

TraceCost::SubCost TraceCost::subCost(TraceCostType* t)
{
  return t ? t->subCost(this) : 0;
}


QString TraceCost::prettySubCost(TraceCostType* t)
{
  TraceCost::SubCost n = t->subCost(this);

  if (n==0) return QString(" 0 ");

  int i = 0;
  QString res = "";

  while (n) {
    res = QChar('0'+int(n%10)) + res;
    if (!((++i)%3))
      res = " " + res;
    n /= 10;
  }
  if (i%3)
    res = " " + res;

  return res;
}



//---------------------------------------------------
// TraceCallCost

TraceCallCost::TraceCallCost()
{
  _callCount = 0;
}

TraceCallCost::~TraceCallCost()
{}


QString TraceCallCost::costString()
{
  return QString("Calls %2").arg(_callCount);

  // FIXME
  //return QString("%1, Calls %2")
  //.arg(TraceCost::costString()).arg(_callCount);
}

void TraceCallCost::clear()
{
  _callCount = 0;
  TraceCost::clear();
}

int TraceCallCost::callCount()
{
  if (_dirty) update();

  return _callCount;
}

void TraceCallCost::addCallCount(int c)
{
  _callCount += c;

  invalidate();
}


//---------------------------------------------------
// TraceCumulativeCost

TraceCumulativeCost::TraceCumulativeCost()
{}

TraceCumulativeCost::~TraceCumulativeCost()
{}

QString TraceCumulativeCost::costString()
{
  return QString("%1, Cumulative %2");
//    .arg(TraceCost::costString())
//    .arg(_cumulative.costString());
}

void TraceCumulativeCost::clear()
{
  _cumulative.clear();
  TraceCost::clear();
}

TraceCost* TraceCumulativeCost::cumulative()
{
  if (_dirty) update();

  return &_cumulative;
}

void TraceCumulativeCost::addCumulative(TraceCost* c)
{
  _cumulative.addCost(c);

  invalidate();
}


//---------------------------------------------------
// TraceListCost

TraceListCost::TraceListCost(bool onlyActiveParts)
{
  // this is for summing up part costs according to active
  // status of a part
  _onlyActiveParts = onlyActiveParts;

  _lastDep = 0;
}

TraceListCost::~TraceListCost()
{}

void TraceListCost::addDep(TraceCost* dep)
{
#if TRACE_ASSERTIONS
  if (_deps.findRef(dep)>=0) {
    qDebug("addDep: %s already in list!",
           dep->fullName().ascii());
    return;
  }
#endif

  _deps.append(dep);
  _lastDep = dep;
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added\n %s (now %d)",
         fullName().ascii(), dep->fullName().ascii(),
         _deps.count());
#endif
}

TraceCost* TraceListCost::findDep(TracePart* part)
{
  if (_lastDep && _lastDep->part() == part)
    return _lastDep;

  TraceCost* dep;
  for (dep = _deps.first(); dep; dep = _deps.next())
    if (dep->part() == part) {
      _lastDep = dep;
      return dep;
    }
  return 0;
}


void TraceListCost::update()
{
  if (!_dirty) return;

#if TRACE_DEBUG
  qDebug("update %s (count %d)",
         fullName().ascii(), _deps.count());
#endif

  clear();
  TraceCost* item;
  for (item = _deps.first(); item; item = _deps.next()) {
    if (_onlyActiveParts)
      if (!item->part() || !item->part()->isActive()) continue;

    addCost(item);
  }

  _dirty = false;

#if TRACE_DEBUG
  qDebug("   > %s", costString().ascii());
#endif
}

//---------------------------------------------------
// TraceCallListCost

TraceCallListCost::TraceCallListCost(bool onlyActiveParts)
{
  // this is for summing up part costs according to active
  // status of a part
  _onlyActiveParts = onlyActiveParts;

  _lastDep = 0;
}

TraceCallListCost::~TraceCallListCost()
{}

void TraceCallListCost::addDep(TraceCallCost* dep)
{
#if TRACE_ASSERTIONS
  if (_deps.findRef(dep)>=0) {
    qDebug("addDep: %s already in list!",
           dep->fullName().ascii());
    return;
  }
#endif

  _deps.append(dep);
  _lastDep = dep;
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added\n %s (now %d)",
         fullName().ascii(), dep->fullName().ascii(),
         _deps.count());
#endif
}

TraceCallCost* TraceCallListCost::findDep(TracePart* part)
{
  if (_lastDep && _lastDep->part() == part)
    return _lastDep;

  TraceCallCost* dep;
  for (dep = _deps.first(); dep; dep = _deps.next())
    if (dep->part() == part) {
      _lastDep = dep;
      return dep;
    }
  return 0;
}


void TraceCallListCost::update()
{
  if (!_dirty) return;

#if TRACE_DEBUG
  qDebug("update %s (count %d)",
         fullName().ascii(), _deps.count());
#endif

  clear();
  TraceCallCost* item;
  for (item = _deps.first(); item; item = _deps.next()) {
    if (_onlyActiveParts)
      if (!item->part() || !item->part()->isActive()) continue;

    addCost(item);
    addCallCount(item->callCount());
  }

  _dirty = false;

#if TRACE_DEBUG
  qDebug("   > %s", costString().ascii());
#endif
}


//---------------------------------------------------
// TraceCumulativeListCost

TraceCumulativeListCost::TraceCumulativeListCost(bool onlyActiveParts)
{
  _onlyActiveParts = onlyActiveParts;
  _lastDep = 0;
}

TraceCumulativeListCost::~TraceCumulativeListCost()
{}


void TraceCumulativeListCost::addDep(TraceCumulativeCost* dep)
{
#if TRACE_ASSERTIONS
  if (_deps.findRef(dep)>=0) {
    qDebug("addDep: %s already in list!",
           dep->fullName().ascii());
    return;
  }
#endif

  _deps.append(dep);
  _lastDep = dep;
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added\n %s (now %d)",
         fullName().ascii(), dep->fullName().ascii(),
         _deps.count());
#endif
}

TraceCumulativeCost* TraceCumulativeListCost::findDep(TracePart* part)
{
  if (_lastDep && _lastDep->part() == part)
    return _lastDep;

  TraceCumulativeCost* dep;
  for (dep = _deps.first(); dep; dep = _deps.next())
    if (dep->part() == part) {
      _lastDep = dep;
      return dep;
    }
  return 0;
}

void TraceCumulativeListCost::update()
{
  if (!_dirty) return;

#if TRACE_DEBUG
  qDebug("update %s (count %d)",
         fullName().ascii(), _deps.count());
#endif

  clear();
  TraceCumulativeCost* item;
  for (item = _deps.first(); item; item = _deps.next()) {
    if (_onlyActiveParts)
      if (!item->part() || !item->part()->isActive()) continue;

    addCost(item);
    addCumulative(item->cumulative());
  }

  _dirty = false;

#if TRACE_DEBUG
  qDebug("   > %s", costString().ascii());
#endif
}

