/*
 * Part of KCacheGrind
 *
 */

#include "tracepart.h"
#include "tracedata.h"

#define TRACE_DEBUG      0
#define TRACE_ASSERTIONS 0

//---------------------------------------------------
// TracePartLineCall

TracePartLineCall::TracePartLineCall(TraceLineCall* lineCall,
                                     TracePart* part)
{
  _part = part;
  _dep = lineCall;
}

TracePartLineCall::~TracePartLineCall()
{}


//---------------------------------------------------
// TracePartLine

TracePartLine::TracePartLine(TraceLine* line, TracePart* part)
{
  _part = part;
  _dep = line;
}

TracePartLine::~TracePartLine()
{}




//---------------------------------------------------
// TracePartCall

TracePartCall::TracePartCall(TraceCall* call, TracePart* part)
{
  _part = part;
  _dep = call;
}

TracePartCall::~TracePartCall()
{}

bool TracePartCall::isRecursion()
{
  return call()->isRecursion();
}

//---------------------------------------------------
// TracePartFunction

TracePartFunction::TracePartFunction(TraceFunction* function,
                                     TracePart* part,
                                     TracePartObject* partObject)
{
  _part = part;
  _dep = function;
  _partObject = partObject;

  _calledCount = _calledContexts = 0;
  _callingCount = _callingContexts = 0;
}

TracePartFunction::~TracePartFunction()
{}

QString TracePartFunction::costString()
{
  update();

  QString res = TraceCumulativeCost::costString();
  res += QString(", called from %1: %2")
         .arg(_calledContexts).arg(_calledCount);
  res += QString(", calling from %1: %2")
         .arg(_callingContexts).arg(_callingCount);

  return res;
}

void TracePartFunction::addPartLine(TracePartLine* ref)
{
#if TRACE_ASSERTIONS
  if (_partLines.findRef(ref)>=0) {
    qDebug("TracePartFunction::addPartLine: %s already in list!",
           ref->name().ascii());
    return;
  }
#endif

  _partLines.append(ref);
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added\n %s (now %d)",
         fullName().ascii(), ref->fullName().ascii(),
         _partLines.count());
#endif
}


void TracePartFunction::addPartCaller(TracePartCall* ref)
{
#if TRACE_ASSERTIONS
  if (_partCallers.findRef(ref)>=0) {
    qDebug("TracePartFunction::addPartCaller: %s already in list!",
           ref->name().ascii());
    return;
  }
#endif

  _partCallers.append(ref);
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added Caller\n %s (now %d)",
         fullName().ascii(), ref->fullName().ascii(),
         _partCallers.count());
#endif
}


void TracePartFunction::addPartCalling(TracePartCall* ref)
{
#if TRACE_ASSERTIONS
  if (_partCallings.findRef(ref)>=0) {
    qDebug("TracePartFunction::addPartCalling: %s already in list!",
           ref->name().ascii());
    return;
  }
#endif

  _partCallings.append(ref);
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added Calling\n %s (now %d)",
         fullName().ascii(), ref->fullName().ascii(),
         _partCallings.count());
#endif
}

int TracePartFunction::calledCount()
{
  if (_dirty) update();

  return _calledCount;
}

int TracePartFunction::calledContexts()
{
  if (_dirty) update();

  return _calledContexts;
}

int TracePartFunction::callingCount()
{
  if (_dirty) update();

  return _callingCount;
}


int TracePartFunction::callingContexts()
{
  if (_dirty) update();

  return _callingContexts;
}


void TracePartFunction::update()
{
  if (!_dirty) return;

#if TRACE_DEBUG
  qDebug("TracePartFunction::update %s (Callers %d, Callings %d, lines %d)",
         name().ascii(), _partCallers.count(), _partCallings.count(),
         _partLines.count());
#endif

  _calledCount = _calledContexts = 0;
  _callingCount = _callingContexts = 0;
  clear();

  // calculate additional cost metrics
  TracePartCall *caller, *calling;
  for (caller=_partCallers.first();caller;caller=_partCallers.next()) {

    // FIXME
    if (caller->subCost(0)>0)
      _calledContexts++;

    int c = caller->callCount();
    if (c>0) {
      _calledCount += c;
    }
  }
  for (calling=_partCallings.first();calling;calling=_partCallings.next()) {
    // FIXME
    if (calling->subCost(0)>0)
      _callingContexts++;

    int c = calling->callCount();
    if (c>0) {
      _callingCount += c;
    }
  }

  // pure cost
  TracePartLine* line;
  for (line = _partLines.first(); line; line = _partLines.next())
    addCost(line);

  // cumulative cost: if possible, use caller sums
  if (_calledCount>0) {
    for (caller=_partCallers.first();caller;caller=_partCallers.next()) {
      // detect simple recursion (no cycle)
      if (caller->isRecursion()) continue;

      addCumulative(caller);
    }
  }
  else {
    // without caller info, use calling sum + line costs
    for (calling=_partCallings.first();calling;calling=_partCallings.next()) {
      // detect simple recursion (no cycle)
      if (calling->isRecursion()) continue;

      addCumulative(calling);
    }
    _dirty = false; // don't recurse!
    addCumulative(this);
  }

  _dirty = false;

#if TRACE_DEBUG
  qDebug("   > %s", costString().ascii());
#endif
}

//---------------------------------------------------
// TracePartFunctionGroup

TracePartFunctionGroup::TracePartFunctionGroup(TracePart* part)
{
  _part = part;
}

TracePartFunctionGroup::~TracePartFunctionGroup()
{}

void TracePartFunctionGroup::addPartCaller(TracePartCall* ref)
{
#if TRACE_ASSERTIONS
  if (_partCallers.findRef(ref)>=0) {
    qDebug("TracePartFunction::addPartCaller: %s already in list!",
           ref->name().ascii());
    return;
  }
#endif

  _partCallers.append(ref);
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added Caller\n %s (now %d)",
         fullName().ascii(), ref->fullName().ascii(),
         _partCallers.count());
#endif
}


void TracePartFunctionGroup::addPartCalling(TracePartCall* ref)
{
#if TRACE_ASSERTIONS
  if (_partCallings.findRef(ref)>=0) {
    qDebug("TracePartFunction::addPartCalling: %s already in list!",
           ref->name().ascii());
    return;
  }
#endif

  _partCallings.append(ref);
  invalidate();

#if TRACE_DEBUG
  qDebug("%s added Calling\n %s (now %d)",
         fullName().ascii(), ref->fullName().ascii(),
         _partCallings.count());
#endif
}


//---------------------------------------------------
// TracePartClass

TracePartClass::TracePartClass(TraceClass* cls, TracePart* part)
    : TracePartFunctionGroup(part)
{
  _dep = cls;
}

TracePartClass::~TracePartClass()
{}

QString TracePartClass::prettyName()
{
  return QString("%1 from %2")
    .arg( _dep->name().isEmpty() ? QString("(global)") : _dep->name())
    .arg(_part->name());
}

//---------------------------------------------------
// TracePartFile

TracePartFile::TracePartFile(TraceFile* file, TracePart* part)
    : TracePartFunctionGroup(part)
{
  _dep = file;
}

TracePartFile::~TracePartFile()
{}


//---------------------------------------------------
// TracePartObject

TracePartObject::TracePartObject(TraceObject* object, TracePart* part)
    : TracePartFunctionGroup(part)
{
  _dep = object;
}

TracePartObject::~TracePartObject()
{}


//---------------------------------------------------
// TracePart

TracePart::TracePart(TraceData* data, QString name)
{
  _dep = data;
  _data = data;
  _name = name;
  _active = true;
}

TracePart::~TracePart()
{}


// strip path
QString TracePart::shortName() const
{
  int lastIndex = 0, index;
  while ( (index=_name.find("/", lastIndex)) >=0)
    lastIndex = index+1;

  return _name.mid(lastIndex);
}

QString TracePart::prettyName()
{
  QString prefix = _data->traceName();
  QString sName = name();

  if (sName.startsWith(prefix))
    return QString("out") + sName.mid(prefix.length());

  return sName;
}

bool TracePart::activate(bool active)
{
  if (_active == active) return false;
  _active = active;

  // to be done by the client of this function
  // _data->invalidateDynamicCost();
  // So better use the TraceData functions...

  return true;
}



