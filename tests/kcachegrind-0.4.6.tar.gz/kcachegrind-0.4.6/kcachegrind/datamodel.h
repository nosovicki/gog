/**
 * Interface definitions for the KCachegrind data model.
 *
 * The basic idea is that a profile experiment delivers
 * relations of an event counter vector to positions
 * in the source code of an executed program.
 *
 * Events simply are named and the counters are 64bit
 * integer values.
 *
 * Positions can be code or data positions, with
 * subpositions like (file name, function name, source line)
 * or (data type, object name, access offset).
 * For more complex data, positions can be multidimensional:
 * E.g. for calls, positions (caller/callee) are tuples
 * of code positions, or for cache evictions, the position
 * could be (data position triggering load of evicted line,
 * data position triggering eviction).
 *
 * Profile data can consist of different event relation
 * types like self cost, calls, and cache evictions.
 *
 * Data files gives costs for fully specified positions.
 * Partly specified positions
 *
 * 
 *
 * Basic classes/objects:
 *  EventCounter  : a 64bit counter
 *  EventType     : an event type
 *  EventVector   : a sequence of event types
 *  Position      : a sequence of positions or subpositions
 *                  this position is derived from
 *  SubPosition   : an atomic position type of a integer or
 *                  a string. It has a short and long name,
 *                  and a semantic like file name/line.
 *  Relation      : A relation type specifying the position
 *                  type and event vector
 *  Cost          : Cost counters for a relation.
 *                  Maps sequences of string subpositions
 *                  and integer subpositions to a vector
 *                  of event counters.
 *  RelationCosts : A set of costs of a specific relation.
 *  ProfileCosts  : The union of multiple relation costs.
 *                  This typically are the data of a profile
 *                  run or a combination of such data.
 *  ProfileData   : A set of ProfileCosts with references
 *                  to same positions.
 *                  This could be multiple runs of the same
 *                  program.
 *  ProfileFilter : Profile costs can rely on a filter
 *                  adding a heuristic or combining data.
 *                  This includes simple sum, but also
 *                  cycle detection, GProf inclusive cost
 *                  propagation
 *
 * Most important is the ProfileCosts class, as it allows
 * to request costs for only partially defined positions,
 * which gives the sum of all costs matching this position.
 *
 * Import filters export a ProfileData object, with
 * notification when new ProfileCosts objects are added.
 */

