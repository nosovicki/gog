/*
 * Builtin cost types with fixed formulas.
 * Copyright (C) 2003, Josef Weidendorfer
 */

#ifndef BUILTINTYPES_H
#define BUILTINTYPES_H

#include "tracedata.h"


/**
 * Costtype ICov dependent on
 *  DID : Distinct Instructions with Debug information
 *  Ir  : Instruction fetches issued
 * Both types have to be available on instruction level.
 * Formula:
 *  ICov = (DID * Ir >0 @ Instr) / DID
 *
 * This gives a measure of how much of code was covered by tests.
 */
class InstrCoverageType: public TraceCostType
{
 public:
  InstrCoverageType();

  



};


#endif
