/****************************************************************************
** Form interface generated from reading ui file './tracesourcedlg.ui'
**
** Created: Mon Aug 11 11:48:03 2003
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.1.1   edited Nov 21 17:40 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef TRACESOURCEDLG_H
#define TRACESOURCEDLG_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class KHistoryCombo;
class QCheckBox;
class QFrame;
class QLabel;
class QPushButton;

class TraceSourceDlg : public QDialog
{
    Q_OBJECT

public:
    TraceSourceDlg( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~TraceSourceDlg();

    KHistoryCombo* TraceExecutable;
    KHistoryCombo* TraceDirectory;
    QPushButton* PushButton11;
    QCheckBox* CheckBox1;
    QLabel* TextLabel2;
    QPushButton* PushButton11_2;
    QFrame* Line3;
    QPushButton* PushButton9;
    QPushButton* PushButton9_2;

public slots:
    virtual void browseDirectorySlot();
    virtual void browseExecSlot();

protected:
    QVBoxLayout* TraceSourceDlgLayout;
    QGridLayout* Layout3;
    QHBoxLayout* Layout11;

protected slots:
    virtual void languageChange();
};

#endif // TRACESOURCEDLG_H
