/*
 * Part of KCacheGrind
 *
 * Classes for event metrics in a thread and time period of a program run,
 * a "trace part".
 *
 * (C) 2003, Josef Weidendorfer
 */

#ifndef TRACEPART_H
#define TRACEPART_H

#include <qstring.h>
#include <qptrlist.h>

#include "tracecost.h"

// classes for summation over trace parts (from tracedata.h)
class TraceLineCall;
class TraceLine;
class TraceCall;
class TraceFunction;
class TraceClass;
class TraceFile;
class TraceObject;
class TraceData;

// forward declaration
class TracePartLine;
class TracePartCall;
class TracePartObject;
class TracePart;

// typedefs for lists
typedef QPtrList<TracePartLine> TracePartLineList;
typedef QPtrList<TracePartCall> TracePartCallList;
typedef QPtrList<TracePart> TracePartList;

/**
 * Cost of a call at a line from a trace file.
 * Cost is always up to date, no lazy update needed.
 */
class TracePartLineCall: public TraceCallCost
{
public:
  TracePartLineCall(TraceLineCall*, TracePart*);
  virtual ~TracePartLineCall();

  virtual CostType type() { return PartLineCall; }
  // fix cost item
  virtual void update() {}
  TraceLineCall* lineCall() const { return (TraceLineCall*) _dep; }
};



/**
 * Cost of a line from a trace file.
 * Cost is always up to date, no lazy update needed.
 */
class TracePartLine: public TraceCost
{
public:
  TracePartLine(TraceLine*, TracePart*);
  virtual ~TracePartLine();

  virtual CostType type() { return PartLine; }
  // fix cost item
  virtual void update() {}

  TraceLine* line() const { return (TraceLine*)_dep; }
};


/**
 * Cost of a call from
 * - a TracePartFunction      to a TracePartFunction
 * - a TracePartFunctionGroup to a TracePartFunctionGroup
 * from a single trace file.
 */
class TracePartCall: public TraceCallListCost
{
public:
  TracePartCall(TraceCall* call, TracePart* part);
  virtual ~TracePartCall();

  virtual CostType type() { return PartCall; }
  // does a cost item call itself?
  bool isRecursion();

  TraceCall* call() const { return (TraceCall*)_dep; }
};



/**
 * Cost of a function,
 * from a single trace file.
 */
class TracePartFunction: public TraceCumulativeCost
{
public:
  TracePartFunction(TraceFunction*, TracePart*, TracePartObject*);
  virtual ~TracePartFunction();

  virtual CostType type() { return PartFunction; }
  virtual void update();
  virtual QString costString();

  void addPartLine(TracePartLine*);
  void addPartCaller(TracePartCall*);
  void addPartCalling(TracePartCall*);

  const TracePartCallList& partCallers() { return _partCallers; }
  const TracePartCallList& partCallings() { return _partCallings; }

  TraceFunction* function() { return (TraceFunction*) _dep; }

  TracePartObject* partObject() { return _partObject; }
  void setPartObject(TracePartObject* o) { _partObject = o; }

  // additional cost metrics
  int calledCount();
  int calledContexts();
  int callingCount();
  int callingContexts();

private:
  TracePartObject* _partObject;
  TracePartLineList _partLines;

  TracePartCallList _partCallings;
  TracePartCallList _partCallers;

  // cached
  int _calledCount, _callingCount;
  int _calledContexts, _callingContexts;
};


/**
 * Base class for metrics of a function group:
 * TracePartClass, TracePartFile, TracePartObject
 */
class TracePartFunctionGroup: public TraceCumulativeListCost
{
 public:
    TracePartFunctionGroup(TracePart*);
    virtual ~TracePartFunctionGroup();

    void addPartFunction(TracePartFunction* f) { addDep(f); }

    void addPartCaller(TracePartCall*);
    void addPartCalling(TracePartCall*);

    const TracePartCallList& partCallers() { return _partCallers; }
    const TracePartCallList& partCallings() { return _partCallings; }

 protected:
    TracePartCallList _partCallings;
    TracePartCallList _partCallers;
};



/**
 * Cost of a class,
 * from a single trace file.
 */
class TracePartClass: public TracePartFunctionGroup
{
public:
  TracePartClass(TraceClass*, TracePart*);
  virtual ~TracePartClass();

  QString prettyName();
  virtual CostType type() { return PartClass; }
  TraceClass* cls() { return (TraceClass*)_dep; }
};


/**
 * Cost of a source file,
 * from a single trace file.
 */
class TracePartFile: public TracePartFunctionGroup
{
public:
  TracePartFile(TraceFile*, TracePart*);
  virtual ~TracePartFile();

  virtual CostType type() { return PartFile; }
  TraceFile* file() { return (TraceFile*)_dep; }
};


/**
 * Cost of a object,
 * from a single trace file.
 */
class TracePartObject: public TracePartFunctionGroup
{
public:
  TracePartObject(TraceObject*, TracePart*);
  virtual ~TracePartObject();

  virtual CostType type() { return PartObject; }
  TraceObject* object() { return (TraceObject*)_dep; }
};



/**
 * A Trace Part: All data read from a trace file, containing all costs
 * that happened in a specified time interval of the executed command.
 */
class TracePart: public TraceListCost
{
public:
  TracePart(TraceData*, QString name);
  virtual ~TracePart();

  virtual CostType type() { return Part; }

  QString shortName() const;
  QString prettyName();
  QString name() { return _name; }
  QString description() const { return _descr; }
  QString trigger() const { return _trigger; }
  QString timeframe() const { return _timeframe; }
  QString version() const { return _version; }
  int counter() { return _counter; }
  void setDescription(const QString& d) { _descr = d; }
  void setTrigger(const QString& t) { _trigger = t; }
  void setTimeframe(const QString& t) { _timeframe = t; }
  void setVersion(const QString& v) { _version = v; }
  void setCounter(int c) { _counter = c; }
  const TraceCostList& items() const { return _items; }
  TraceData* data() const { return _data; }
  TraceCost* totals() { return &_totals; }


  // returns true if something changed
  bool activate(bool);
  bool isActive() { return _active; }

private:
  QString _name;

  QString _descr;
  QString _trigger;
  QString _timeframe;
  QString _version;

  int _counter;
  TraceCostList _items;
  TraceData* _data;

  bool _active;

  // the totals line
  TraceCost _totals;

};


#endif
