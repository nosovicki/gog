/*
 * Part of KCacheGrind
 *
 * Base classes containing profile event metrics for profile actions.
 *
 * (C) 2003, Josef Weidendorfer
 */

#ifndef TRACECOST_H
#define TRACECOST_H

#include <qstring.h>
#include <qptrlist.h>

// see tracecosttype.h
class TraceCostType;
class TraceCostMapping;
class TraceSubMapping;

// see tracepart.h
class TracePart;

// forward declarations
class TraceCost;
class TraceCallCost;
class TraceCumulativeCost;

// typedefs for lists
typedef QPtrList<TraceCost> TraceCostList;
typedef QPtrList<TraceCallCost> TraceCallCostList;
typedef QPtrList<TraceCumulativeCost> TraceCumulativeCostList;

/**
 * An array of basic cost metrics for a trace item.
 *
 * The semantic of specific indexes is stored in the
 * TraceCostMapping of the TraceData object holding this TraceCost.
 */
class TraceCost
{
public:
  /**
   * The maximal number of subcosts a TraceCost can have.
   */
  static const int MaxRealIndex = 10;
  static const int InvalidIndex = -1;

  /**
   * RTTI for trace classes, using type() method
   */
  enum CostType { Abstract,
                  PartLine, Line,
                  PartLineCall, LineCall,
                  PartCall, Call, Cycle,
                  PartClass, PartFile, PartObject,
                  PartFunction, FunctionSourceFile,
		  Function, FunctionCall, FunctionCycle,
		  Class, ClassCall, ClassCycle,
		  File, FileCall, FileCycle,
		  Object, ObjectCall, ObjectCycle,
                  Part, Data,
                  MaxCostType, NoCostType };

  typedef long long unsigned SubCost;

  /**
   * Constructs an zero'd metric array with no dependencies
   */
  TraceCost();
  virtual ~TraceCost() {};

  /**
   * for run time type information of event metric classes
   */
  virtual CostType type() { return Abstract; }

  /**
   * Static method for getting a string representation of a class type
   * The returned string is untranslated, but can be translated with i18n()
   */
  static QString typeName(CostType);

  /**
   * Same as typeName(CostType) for a object instance derived from TraceCost
   */
  QString typeName() { return typeName(type()); }

  /**
   * Reverse of typeName().
   */
  static CostType    costType(QString);

  /**
   * Returns dynamic name info (without type)
   */
  virtual QString name();

  /**
   * Same as name, but sometimes nicer for humans :-)
   */
  virtual QString prettyName() { return name(); }

  /**
   * Returns text of all cost metrics
   */
  virtual QString costString(TraceCostMapping*);

  /**
   * Returns type name + dynamic name
   */
  QString fullName();

  /**
   * Returns full name + cost text
   */
  QString toString();


  virtual void clear();

  // set the cost according to a submapping and a list of ASCII numbers
  void set(TraceSubMapping*, const char*);
  // add a cost according to a submapping and a list of ASCII numbers
  void addCost(TraceSubMapping*, const char*);
  // add the cost of another item
  void addCost(TraceCost* item, TraceCostMapping* m = 0);
  void addCost(int index, SubCost value);
  TraceCost diff(TraceCost* item);

  /** Invalidate the cost attributes.
   * An invalidated object needs to be recalculated when a cost
   * attribute is requested (e.g. by subCost()).
   * Has to be overwritten by subclasses when the cost influences costs of
   * other cost items. If only one item depends on the cost of this item,
   * it can by set with setDependant() without a need for overwriting.
   */
  virtual void invalidate();

  /**
   * Sets a dependant to be invalidated when this cost is invalidated.
   * Call this function directly after the constructor.
   */
  void setDependant(TraceCost* d) { _dep = d; }

  TraceCost* dependant() { return _dep; }

  /**
   * If this cost is not derived, but from a single trace file
   * set the trace file (=part) with this function.
   * Call this function directly after the constructor.
   */
  void setPart(TracePart* p) { _part = p; }

  TracePart* part() { return _part; }

  /** Returns a sub cost. This automatically triggers
   * a call to update() if needed.
   */
  SubCost subCost(TraceCostType*);

  /**
   * Same as above, but only for real types giving the index
   */
  SubCost subCost(int);

  /** Returns a cost attribute converted to a string
   * (with space after 3 digits)
   */
  QString prettySubCost(TraceCostType*);

protected:
  /** Updates cost attributes.
   * This has to be called by subclasses that access cost attributes
   * directly
   */
  virtual void update();

  SubCost _cost[MaxRealIndex];
  bool _dirty;

  TracePart* _part;
  TraceCost* _dep;
};

/**
 * Cost item with additional call count metric.
 */
class TraceCallCost: public TraceCost
{
public:
  TraceCallCost();
  virtual ~TraceCallCost();

  // reimplementations for cost addition
  virtual QString costString();
  virtual void clear();

  // additional cost metric
  int callCount();
  void addCallCount(int c);

protected:
  int _callCount;
};


/**
 * Cost item with additional cumulative metric
 */
class TraceCumulativeCost: public TraceCost
{
public:
  TraceCumulativeCost();
  virtual ~TraceCumulativeCost();

  // reimplementations for cost addition
  virtual QString costString();
  virtual void clear();

  // additional cost metric
  TraceCost* cumulative();
  void addCumulative(TraceCost*);

protected:
  TraceCost _cumulative;
};


/**
 * Cost Item
 * dependend on a list of cost items.
 */
class TraceListCost: public TraceCost
{
public:
  TraceListCost(bool onlyActiveParts = false);
  virtual ~TraceListCost();

  // reimplementation for dependency list
  virtual void update();

  TraceCostList* deps() { return &_deps; }
  void addDep(TraceCost*);
  TraceCost* findDep(TracePart*);

protected:
  TraceCostList _deps;
  bool _onlyActiveParts;

private:
  // very temporary: cached
  TraceCost* _lastDep;
};



/**
 * Call Cost Item
 * dependend on a list of Call cost items.
 */
class TraceCallListCost: public TraceCallCost
{
public:
  TraceCallListCost(bool onlyActiveParts = false);
  virtual ~TraceCallListCost();

  // reimplementation for dependency list
  virtual void update();

  TraceCallCostList* deps() { return &_deps; }
  void addDep(TraceCallCost*);
  TraceCallCost* findDep(TracePart*);

protected:
  TraceCallCostList _deps;
  bool _onlyActiveParts;

private:
  // very temporary: cached
  TraceCallCost* _lastDep;
};


/**
 * Cumulative Cost Item dependend on a list of cumulative cost items.
 */
class TraceCumulativeListCost: public TraceCumulativeCost
{
public:
  TraceCumulativeListCost(bool onlyActiveParts = false);
  virtual ~TraceCumulativeListCost();

  // reimplementation for dependency
  virtual void update();

  TraceCumulativeCostList* deps() { return &_deps; }
  void addDep(TraceCumulativeCost*);
  TraceCumulativeCost* findDep(TracePart*);

protected:
  TraceCumulativeCostList _deps;
  bool _onlyActiveParts;

private:
  // very temporary: cached
  TraceCumulativeCost* _lastDep;
};


#endif
