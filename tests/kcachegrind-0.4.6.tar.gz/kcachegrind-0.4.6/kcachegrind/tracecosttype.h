/*
 * Part of KCacheGrind
 *
 * Classes for profile event types and mapping of cost indexes
 * in TraceCost derived classes to event types.
 *
 * (C) 2003, Josef Weidendorfer
 */

#ifndef TRACECOSTTYPE_H
#define TRACECOSTTYPE_H

#include <qstring.h>

#include "tracecost.h"


// forward declaration
class TraceCostMapping;

/**
 * A cost type, e.g. "L1 Read Miss", short "l1rm".
 *
 * We distinguish "real" cost types, where the values come
 * from the trace file, and "virtual" cost types, which
 * are calculated from the real ones.
 *
 * For a virtual cost type, set a formula to calculate it:
 * e.g. for "Read Misses" : "l1rm + l2rm".
 * To allow for parsing, you must specify a TraceCostMapping
 * with according cost types (e.g. "l1rm" and "l2rm" for above formula).
 */
class TraceCostType
{
public:

  /**
   * <name> is a short identifier for the cost type, e.g. "l1rm".
   * <longname> is e.g. "L1 Read Miss"
   */
  TraceCostType(QString name,
                QString longname = QString::null,
                QString formula = QString::null);

  void setLongName(QString n) { _longName = n; }
  void setMapping(TraceCostMapping* m);
  void setFormula(QString);
  // default arg is for specifying a real type, but index unknown
  void setRealIndex(int r = TraceCost::MaxRealIndex);

  const QString& name() { return _name; }
  const QString& longName() { return _longName; }
  const QString& formula() { return _formula; }
  TraceCostMapping* mapping() { return _mapping; }
  int realIndex() { return _realIndex; }
  bool isReal() { return _formula.isEmpty(); }

  /**
   * returns true if all cost type names can be resolved in formula
   */
  bool parseFormula();

  /**
   * Returns a beautified version of a formula.
   * This parses a formula if not already parsed.
   */
  QString parsedFormula();

  /**
   * Return the cost with this type of a item
   */
  TraceCost::SubCost subCost(TraceCost*);

  // application wide known types
  static TraceCostType* knownRealType(QString);
  static TraceCostType* knownVirtualType(QString);
  static void add(TraceCostType*);
  static int knownTypeCount();
  static TraceCostType* knownType(int);

private:

  QString _name, _longName, _description, _formula;
  TraceCostMapping* _mapping;
  bool _parsed, _inParsing;
  int _coefficient[TraceCost::MaxRealIndex];
  int _realIndex;

  static QPtrList<TraceCostType>* _knownTypes;
};


/**
 * A class for managing a set of cost types.
 *
 * Each cost type has an index:
 * - Real costs are in range [0 .. TraceCost:MaxRealIndex[
 * - Virtual costs are in range [MaxRealIndex, ...]
 */
class TraceCostMapping
{
public:
  TraceCostMapping();
  ~TraceCostMapping();

  /**
   * Defines a sub mapping with a list of real types
   * If <create> is false, checks if this is a existing sub mapping.
   */
  TraceSubMapping* subMapping(QString types, bool create = true);

  // "knows" about some real types
  int addReal(QString);
  int add(TraceCostType*);
  int realCount() { return _realCount; }
  int virtualCount() { return _virtualCount; }
  int minVirtualIndex() { return TraceCost::MaxRealIndex; }
  TraceCostType* type(int);
  TraceCostType* realType(int);
  TraceCostType* virtualType(int);
  TraceCostType* type(QString);
  TraceCostType* typeForLong(QString);
  int realIndex(QString);
  int index(QString);

  /**
   * Adds all known virtual types that can be parsed
   */
  int addKnownVirtualTypes();

private:
  // we support only a fixed number of real and virtual types
  TraceCostType* _real[TraceCost::MaxRealIndex];
  TraceCostType* _virtual[TraceCost::MaxRealIndex];
  int _realCount, _virtualCount;
};

/**
 * A submapping of a TraceCostMapping
 *
 * This is a fixed ordered list of indexes for real cost types
 * in a mapping.
 *
 * You can define a mapping by requesting submappings. Undefined cost
 * types will get a new real type index.
 *  TraceCostMapping m;
 *  sm1 = m.subMapping("Event1 Cost1 Cost2");  // returns submap [0,1,2]
 *  sm2 = m.subMapping("Event2 Cost3 Event1"); // returns submap [3,4,0]
 * Real types of m will be:
 *  (0:Event1, 1:Cost1, 2:Cost2, 3:Event2, 4:Cost3)
 */
class TraceSubMapping
{
public:
  TraceSubMapping(TraceCostMapping*);

  bool append(QString, bool create=true);
  bool append(int);
  void clear() { _count = 0; }

  int count() { return _count; }
  int realIndex(int i)
    { return (i<0 || i>=_count) ? TraceCost::InvalidIndex : _realIndex[i]; }

private:
  TraceCostMapping* _mapping;
  int _count;
  int _realIndex[TraceCost::MaxRealIndex];
};

#endif // TRACECOSTTYPE_H
